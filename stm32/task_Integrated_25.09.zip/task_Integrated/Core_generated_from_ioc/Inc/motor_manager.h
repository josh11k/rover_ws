#ifndef MOTOR_MANAGER_H_
#define MOTOR_MANAGER_H_

#include <stdint.h>

void MotorManager_Init(void); // Initializes the configured motor table.
void MotorManager_Task(void); // Runs connection, discovery, movement, and LED tasks.
void MotorManager_ExecuteCommand(const char *input); // Executes one complete terminal command.
uint8_t MotorManager_SetMastAngles(int16_t pitchDeg, int16_t rollDeg); // Converts mast pitch/roll angles to motor targets and starts a sync move.
uint8_t MotorManager_GetPositionById(uint8_t motorId, uint16_t *position, uint8_t *connected); // Returns cached position/connection state.

#endif // MOTOR_MANAGER_H_
