#include "rover_housekeeping.h"

#include "fan_control.h"
#include "fan_driver.h"
#include "ina228.h"
#include "motor_manager.h"
#include "rover_state.h"
#include "temperature_sensor.h"

#include <stdio.h>
#include <string.h>

#define INA_ADDRESS_MIN 0x40U
#define INA_ADDRESS_MAX 0x4FU
#define HK_MAX_INA_COUNT 4U
#define HK_TEMP_INTERVAL_MS 1000U
#define HK_INA_INTERVAL_MS 1000U
#define HK_REPORT_INTERVAL_MS 2000U

static TemperatureSensorData latestTemperature;
static uint8_t temperatureValid = 0U;

static uint8_t inaAddresses[HK_MAX_INA_COUNT];
static INA228_Measurement inaMeasurements[HK_MAX_INA_COUNT];
static uint8_t inaValid[HK_MAX_INA_COUNT];
static uint8_t inaCount = 0U;

static uint32_t lastTempTick = 0U;
static uint32_t lastInaTick = 0U;
static uint32_t lastReportTick = 0U;

static void PrintFloat1(float value)
{
    int32_t v = (int32_t)(value * 10.0f + (value >= 0.0f ? 0.5f : -0.5f));

    if (v < 0)
    {
        printf("-");
        v = -v;
    }

    printf("%ld.%ld", (long)(v / 10), (long)(v % 10));
}

static void PrintVoltageMilliV(uint32_t milliV)
{
    printf("%lu.%03luV",
           (unsigned long)(milliV / 1000U),
           (unsigned long)(milliV % 1000U));
}

static void PrintSignedMicroAAsA(int32_t microA)
{
    int32_t absolute;

    if (microA < 0)
    {
        printf("-");
        absolute = -microA;
    }
    else
    {
        absolute = microA;
    }

    printf("%ld.%03ldA",
           (long)(absolute / 1000000L),
           (long)((absolute % 1000000L) / 1000L));
}

static void PrintSignedMilliC(int32_t milliC)
{
    int32_t absolute;

    if (milliC < 0)
    {
        printf("-");
        absolute = -milliC;
    }
    else
    {
        absolute = milliC;
    }

    printf("%ld.%03ld\xC2\xB0""C",
           (long)(absolute / 1000L),
           (long)(absolute % 1000L));
}

static void ScanINADevices(void)
{
    inaCount = 0U;
    memset(inaValid, 0, sizeof(inaValid));

    for (uint8_t address = INA_ADDRESS_MIN;
         address <= INA_ADDRESS_MAX && inaCount < HK_MAX_INA_COUNT;
         address++)
    {
        if (INA228_IsReady(address))
        {
            inaAddresses[inaCount] = address;
            inaValid[inaCount] = 0U;

            if (INA228_SetAveraging64(address))
            {
                printf("INA%u detected at 0x%02X, averaging=64\r\n",
                       (unsigned)(inaCount + 1U),
                       address);
            }
            else
            {
                printf("INA%u detected at 0x%02X, averaging setup failed\r\n",
                       (unsigned)(inaCount + 1U),
                       address);
            }

            inaCount++;
        }
    }

    if (inaCount == 0U)
    {
        printf("No INA228 detected\r\n");
    }
}

static void ReadTemperatures(void)
{
    if (TemperatureSensor_Read(&latestTemperature))
    {
        temperatureValid = 1U;

        float maxTemperature = -1000.0f;
        uint8_t hasValidMotorTemperature = 0U;

        for (uint8_t i = 0U; i < TEMP_SENSOR_COUNT; i++)
        {
            if (latestTemperature.valid[i] &&
                (!hasValidMotorTemperature || latestTemperature.temperature[i] > maxTemperature))
            {
                maxTemperature = latestTemperature.temperature[i];
                hasValidMotorTemperature = 1U;
            }
        }

        if (hasValidMotorTemperature)
        {
            FanControl_SetTemperature((int)(maxTemperature + 0.5f));
        }
    }
    else
    {
        temperatureValid = 0U;
    }
}

static void ReadINADevices(void)
{
    for (uint8_t i = 0U; i < inaCount; i++)
    {
        inaValid[i] = INA228_ReadMeasurement(inaAddresses[i],
                                             &inaMeasurements[i]);
    }
}

static void PrintHousekeeping(void)
{
    printf(">>HOUSE_KEEPING_DATA:\r\n");
    printf("Time: %lus\r\n", (unsigned long)(HAL_GetTick() / 1000U));
    printf("stm_state: %s\r\n", StateToString());

    if (inaCount > 0U && inaValid[0])
    {
        printf("stm_voltage: ");
        PrintVoltageMilliV(inaMeasurements[0].busVoltageMilliV);
        printf("\r\n");

        printf("stm_current: ");
        PrintSignedMicroAAsA(inaMeasurements[0].currentMicroA);
        printf("\r\n");
    }
    else
    {
        printf("stm_voltage: NA\r\n");
        printf("stm_current: NA\r\n");
    }

    printf("stm_fault: %s\r\n", FaultToString());

    for (uint8_t i = 0U; i < TEMP_SENSOR_COUNT; i++)
    {
        printf("Temp. Motor %u: T=", (unsigned)(i + 1U));

        if (temperatureValid && latestTemperature.valid[i])
        {
            PrintFloat1(latestTemperature.temperature[i]);
            printf("\xC2\xB0""C");
        }
        else
        {
            printf("NA");
        }

        printf("\r\n");
    }

    for (uint8_t motorId = 1U; motorId <= 5U; motorId++)
    {
        uint16_t position;
        uint8_t connected;

        printf("Position Motor %u: ", (unsigned)motorId);

        if (MotorManager_GetPositionById(motorId, &position, &connected) && connected)
        {
            printf("%u", (unsigned)position);
        }
        else
        {
            printf("NA");
        }

        printf("\r\n");
    }

    printf("FAN: %s\r\n", FanControl_GetPWM() > 0U ? "On" : "Off");
    printf("FAN: %lurpm\r\n", (unsigned long)FanDriver_GetRPM());

    for (uint8_t i = 0U; i < HK_MAX_INA_COUNT; i++)
    {
        printf("INA%u: ", (unsigned)(i + 1U));

        if (i < inaCount && inaValid[i])
        {
            printf("V=");
            PrintVoltageMilliV(inaMeasurements[i].busVoltageMilliV);
            printf(", A=");
            PrintSignedMicroAAsA(inaMeasurements[i].currentMicroA);
            printf(", T=");
            PrintSignedMilliC(inaMeasurements[i].temperatureMilliC);
        }
        else
        {
            printf("NA");
        }

        printf("\r\n");
    }

    printf("<<\r\n");
}

void RoverHousekeeping_Init(ADC_HandleTypeDef *hadc)
{
    TemperatureSensor_Init(hadc);
    memset(&latestTemperature, 0, sizeof(latestTemperature));
    temperatureValid = 0U;

    ScanINADevices();
    ReadTemperatures();
    ReadINADevices();

    lastTempTick = HAL_GetTick();
    lastInaTick = HAL_GetTick();
    lastReportTick = HAL_GetTick() - HK_REPORT_INTERVAL_MS;
}

void RoverHousekeeping_Task(void)
{
    uint32_t now = HAL_GetTick();

    if (now - lastTempTick >= HK_TEMP_INTERVAL_MS)
    {
        lastTempTick = now;
        ReadTemperatures();
    }

    if (now - lastInaTick >= HK_INA_INTERVAL_MS)
    {
        lastInaTick = now;
        ReadINADevices();
    }

    if (now - lastReportTick >= HK_REPORT_INTERVAL_MS)
    {
        lastReportTick = now;
        PrintHousekeeping();
    }
}
