#include "rover_protocol.h"


#include "motor_manager.h"
#include "rover_state.h"

#include <ctype.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define RX_LINE_BUFFER_SIZE 160U
#define JETSON_ALIVE_TIMEOUT_MS 180000U

#define JETSON_MOTOR_CODE_MIN      25L
#define JETSON_MOTOR_CODE_MAX      998L

#define SET_MOTOR_PAIR_MAX_COUNT   5U
#define SET_MOTOR_ID_MIN           1U
#define SET_MOTOR_ID_MAX           5U
#define SET_MOTOR_TARGET_MIN       25U
#define SET_MOTOR_TARGET_MAX       998U

static UART_HandleTypeDef *protocolUart = NULL;
static char rxLine[RX_LINE_BUFFER_SIZE];
static uint8_t rxIndex = 0U;
static uint8_t rxOverflow = 0U;
static uint32_t lastAliveTick = 0U;
static uint8_t aliveTimeoutReported = 0U;

static char *Trim(char *text)
{
    char *end;

    while (*text != '\0' && isspace((unsigned char)*text))
    {
        text++;
    }

    if (*text == '\0')
    {
        return text;
    }

    end = text + strlen(text) - 1U;
    while (end > text && isspace((unsigned char)*end))
    {
        *end = '\0';
        end--;
    }

    return text;
}

static char *UnframeJetsonMessage(char *line)
{
    size_t length;
    char *message;

    line = Trim(line);
    length = strlen(line);

    if (length >= 4U && line[0] == '>' && line[1] == '>' &&
        line[length - 2U] == '<' && line[length - 1U] == '<')
    {
        line[length - 2U] = '\0';
        message = line + 2U;
        return Trim(message);
    }

    return line;
}

static FaultCode ParseFault(const char *text)
{
    if (strcmp(text, "VOLTAGE_HIGH") == 0) return FAULT_VOLTAGE_HIGH;
    if (strcmp(text, "TEMP_HIGH") == 0)    return FAULT_TEMP_HIGH;
    if (strcmp(text, "CURRENT_HIGH") == 0) return FAULT_CURRENT_HIGH;
    if (strcmp(text, "COMM_TIMEOUT") == 0) return FAULT_COMM_TIMEOUT;
    if (strcmp(text, "JETSON_ERROR") == 0) return FAULT_JETSON_ERROR;
    return FAULT_UNKNOWN;
}

static const char *SkipSpaces(const char *p)
{
    while ((*p == ' ') || (*p == '\t'))
    {
        p++;
    }

    return p;
}

static uint8_t IsCommandEnd(char c)
{
    return (uint8_t)((c == '\0') || (c == '\r') || (c == '\n'));
}

static uint8_t ParseSetMotorPairs(const char *payload,
                                  uint8_t *ids,
                                  uint16_t *targets,
                                  uint8_t *count)
{
    const char *p = payload;
    char *endPtr = NULL;
    uint8_t pairCount = 0U;
    uint8_t usedIds[SET_MOTOR_ID_MAX + 1U] = {0U};

    if ((payload == NULL) || (ids == NULL) || (targets == NULL) || (count == NULL))
    {
        return 0U;
    }

    while (1)
    {
        uint32_t idValue;
        uint32_t targetValue;

        p = SkipSpaces(p);

        if (IsCommandEnd(*p))
        {
            break;
        }

        if (pairCount >= SET_MOTOR_PAIR_MAX_COUNT)
        {
            return 0U;
        }

        idValue = strtoul(p, &endPtr, 10);
        if (endPtr == p)
        {
            return 0U;
        }

        p = SkipSpaces(endPtr);

        if (*p != ',')
        {
            return 0U;
        }

        p++;
        p = SkipSpaces(p);

        targetValue = strtoul(p, &endPtr, 10);
        if (endPtr == p)
        {
            return 0U;
        }

        if ((idValue < SET_MOTOR_ID_MIN) || (idValue > SET_MOTOR_ID_MAX))
        {
            return 0U;
        }

        if ((targetValue < SET_MOTOR_TARGET_MIN) || (targetValue > SET_MOTOR_TARGET_MAX))
        {
            return 0U;
        }

        if (usedIds[idValue] != 0U)
        {
            return 0U;
        }

        usedIds[idValue] = 1U;
        ids[pairCount] = (uint8_t)idValue;
        targets[pairCount] = (uint16_t)targetValue;
        pairCount++;

        p = SkipSpaces(endPtr);

        if (*p == ',')
        {
            p++;
            continue;
        }

        if (IsCommandEnd(*p))
        {
            break;
        }

        return 0U;
    }

    if (pairCount == 0U)
    {
        return 0U;
    }

    *count = pairCount;
    return 1U;
}

static uint8_t BuildSyncCommandFromSetMotor(const uint8_t *ids,
                                            const uint16_t *targets,
                                            uint8_t count,
                                            char *syncCommand,
                                            size_t syncCommandSize)
{
    int written;
    size_t used = 0U;

    if ((ids == NULL) || (targets == NULL) || (syncCommand == NULL) || (syncCommandSize == 0U))
    {
        return 0U;
    }

    written = snprintf(syncCommand, syncCommandSize, "sync");
    if ((written < 0) || ((size_t)written >= syncCommandSize))
    {
        return 0U;
    }

    used = (size_t)written;

    for (uint8_t i = 0U; i < count; i++)
    {
        written = snprintf(&syncCommand[used],
                           syncCommandSize - used,
                           " %u %u",
                           (unsigned int)ids[i],
                           (unsigned int)targets[i]);

        if ((written < 0) || ((size_t)written >= (syncCommandSize - used)))
        {
            return 0U;
        }

        used += (size_t)written;
    }

    return 1U;
}

static void PrintHelp(void)
{
    printf("Integrated STM test commands:\r\n");
    printf("  >>ALIVE: IDLE<<\r\n");
    printf("  >>SET_STATE: IDLE<<\r\n");
    printf("  >>SET_STATE: MAST_DEPLOYMENT<<\r\n");
    printf("  >>SET_STATE: STANDBY<<\r\n");
    printf("  >>SET_STATE: AUTO<<\r\n");
    printf("  >>SET_MOTOR: 1,512<<\r\n");
    printf("  >>SET_MOTOR: 1,512,3,650,2,430<<  (id,target pairs, any order)\r\n");
    printf("  >>ERROR: TEMP_HIGH<<\r\n");
    printf("  RECOVER\r\n");
    printf("  pos / status / s / b / si  (direct motor debug commands)\r\n");
}

static void ProcessCommand(char *line)
{
    char *message;
    char *payload;

    if (rxOverflow)
    {
        SendNack("COMMAND_TOO_LONG");
        rxOverflow = 0U;
        return;
    }

    message = UnframeJetsonMessage(line);

    if (message[0] == '\0')
    {
        return;
    }

    if (strcmp(message, "help") == 0 || strcmp(message, "HELP") == 0)
    {
        PrintHelp();
        return;
    }

    if (strcmp(message, "state") == 0 || strcmp(message, "STATE") == 0)
    {
        PrintState();
        return;
    }

    if (strcmp(message, "RECOVER") == 0 || strcmp(message, "recover") == 0)
    {
        RecoverFromFault();
        return;
    }

    if (strncmp(message, "ALIVE:", 6U) == 0)
    {
        lastAliveTick = HAL_GetTick();
        aliveTimeoutReported = 0U;
        SendAck("ALIVE");
        return;
    }

    if (strncmp(message, "ERROR:", 6U) == 0)
    {
        payload = Trim(message + 6U);
        ReportFault(ParseFault(payload));
        return;
    }

    if (strncmp(message, "SET_STATE:", 10U) == 0)
    {
        payload = Trim(message + 10U);

        if (RoverState_SetStateFromString(payload))
        {
            SendAck("SET_STATE");
            PrintState();
        }
        else
        {
            SendNack(RoverState_IsLocked() ? "STATE_LOCKED_SAFE" : "UNKNOWN_STATE");
        }
        return;
    }

    if (strncmp(message, "SET_MOTOR:", 10U) == 0)
    {
        uint8_t ids[SET_MOTOR_PAIR_MAX_COUNT];
        uint16_t targets[SET_MOTOR_PAIR_MAX_COUNT];
        uint8_t pairCount = 0U;
        char syncCommand[96];

        if (RoverState_IsLocked())
        {
            SendNack("STATE_LOCKED_SAFE");
            return;
        }

        if (!ParseSetMotorPairs(message + 10U, ids, targets, &pairCount))
        {
            SendNack("INVALID_MOTOR_COMMAND");
            return;
        }

        if (!BuildSyncCommandFromSetMotor(ids,
                                          targets,
                                          pairCount,
                                          syncCommand,
                                          sizeof(syncCommand)))
        {
            SendNack("MOTOR_COMMAND_TOO_LONG");
            return;
        }

        SendAck("MOTOR");
        MotorManager_ExecuteCommand(syncCommand);
        return;
    }

    if (strncmp(message, "MOTOR_CMD:", 10U) == 0 ||
        strncmp(message, "RAW_MOTOR:", 10U) == 0)
    {
        payload = Trim(message + 10U);
        MotorManager_ExecuteCommand(payload);
        return;
    }

    if ((strcmp(message, "mast d") == 0) ||
        (strcmp(message, "MAST_TEST") == 0))
    {
        MotorManager_RunMastCoordinatedMove();
        return;
    }

    /* Direct motor debug commands inherited from Task 5.6. */
    if (strcmp(message, "s") == 0 || strcmp(message, "b") == 0 ||
        strcmp(message, "h") == 0 ||
        strcmp(message, "clear") == 0 ||
        strcmp(message, "i") == 0 || strcmp(message, "si") == 0 ||
        strcmp(message, "pos") == 0 || strcmp(message, "status") == 0 ||
        strncmp(message, "sync ", 5U) == 0 || strncmp(message, "mix ", 4U) == 0 ||
        (message[0] >= '0' && message[0] <= '9'))
    {
        MotorManager_ExecuteCommand(message);
        return;
    }

    SendNack("UNKNOWN_COMMAND");
}

void RoverProtocol_Init(UART_HandleTypeDef *uart)
{
    protocolUart = uart;
    rxIndex = 0U;
    rxOverflow = 0U;
    lastAliveTick = HAL_GetTick();
    aliveTimeoutReported = 0U;
}

void RoverProtocol_Task(void)
{
    if (protocolUart == NULL)
    {
        return;
    }

    for (uint8_t i = 0U; i < 32U; i++)
    {
        uint8_t ch;
        HAL_StatusTypeDef result;

        result = HAL_UART_Receive(protocolUart, &ch, 1U, 1U);
        if (result != HAL_OK)
        {
            break;
        }

        if (ch == '\r' || ch == '\n')
        {
            if (rxIndex > 0U || rxOverflow)
            {
                rxLine[rxIndex] = '\0';
                ProcessCommand(rxLine);
            }

            rxIndex = 0U;
            rxOverflow = 0U;
        }
        else
        {
            if (rxIndex < (RX_LINE_BUFFER_SIZE - 1U))
            {
                rxLine[rxIndex++] = (char)ch;
            }
            else
            {
                rxOverflow = 1U;
            }
        }
    }
}

void RoverProtocol_CheckAliveTimeout(void)
{
    uint32_t now = HAL_GetTick();

    if (!aliveTimeoutReported &&
        activeFault == FAULT_NONE &&
        (now - lastAliveTick) > JETSON_ALIVE_TIMEOUT_MS)
    {
        aliveTimeoutReported = 1U;
        ReportFault(FAULT_COMM_TIMEOUT);
    }
}

void SendAck(const char *message)
{
    printf(">>ACK, %s<<\r\n", message);
}

void SendNack(const char *reason)
{
    printf(">>NACK, %s<<\r\n", reason);
}
